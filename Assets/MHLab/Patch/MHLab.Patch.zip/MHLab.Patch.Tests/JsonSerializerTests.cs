﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using MHLab.Patch.Core;
using MHLab.Patch.Core.Serializing;
using MHLab.Patch.Core.Versioning;
using MHLab.Patch.Tests.Utilities;
using NUnit.Framework;
using Version = MHLab.Patch.Core.Versioning.Version;

namespace MHLab.Patch.Tests
{
    public class JsonSerializerTests
    {
        [Test]
        public void BuildsIndex_Serialize_Test()
        {
            var buildIndex = new BuildsIndex();
            buildIndex.AvailableBuilds = new List<IVersion>(2);
            buildIndex.AvailableBuilds.Add(new Version("0.1.0"));
            buildIndex.AvailableBuilds.Add(new Version("0.1.1"));

            var serialized = JsonUtility.ToJson(buildIndex);

            Assert.False(string.IsNullOrWhiteSpace(serialized));

            var deserializedBuildIndex = new BuildsIndex();
            JsonUtility.Parse(deserializedBuildIndex, serialized);

            Assert.AreEqual(buildIndex.AvailableBuilds.Count, deserializedBuildIndex.AvailableBuilds.Count);

            for (var i = 0; i < buildIndex.AvailableBuilds.Count; i++)
            {
                var expected = buildIndex.AvailableBuilds[i];
                var actual   = deserializedBuildIndex.AvailableBuilds[i];

                Assert.AreEqual(expected, actual);
            }
        }

        [Test]
        public void BuildsIndex_Deserialize_With_Additional_Fields_Test()
        {
            var buildIndex = new BuildsIndex();
            var json = "{\"AnotherRandomField\": \"WithARandomValue\", \"AvailableBuilds\": [\"0.1.0\", \"0.1.1\"]}";

            JsonUtility.Parse(buildIndex, json);

            Assert.NotNull(buildIndex.AvailableBuilds);
            Assert.AreEqual(2, buildIndex.AvailableBuilds.Count);
            Assert.AreEqual(new Version("0.1.0"), buildIndex.AvailableBuilds[0]);
            Assert.AreEqual(new Version("0.1.1"), buildIndex.AvailableBuilds[1]);
        }

        [Test]
        public void BuildsIndex_Deserialize_Without_The_Correct_Field_Test()
        {
            var buildIndex = new BuildsIndex();
            var json       = "{\"AnotherRandomField\": \"WithARandomValue\"}";

            JsonUtility.Parse(buildIndex, json);

            Assert.NotNull(buildIndex.AvailableBuilds);
            Assert.AreEqual(0, buildIndex.AvailableBuilds.Count);
        }

        [Test]
        public void BuildsIndex_Deserialize_With_An_Empty_Correct_Field_Test()
        {
            var buildIndex = new BuildsIndex();
            var json       = "{\"AvailableBuilds\": []}";

            JsonUtility.Parse(buildIndex, json);

            Assert.NotNull(buildIndex.AvailableBuilds);
            Assert.AreEqual(0, buildIndex.AvailableBuilds.Count);
        }


        [Test]
        public void BuildDefinition_Serialize_Test()
        {
            var buildDefinition = new BuildDefinition();
            buildDefinition.Entries = new BuildDefinitionEntry[2];
            buildDefinition.Entries[0] = new BuildDefinitionEntry()
            {
                Attributes   = FileAttributes.Archive,
                Hash         = FakeDataTestHelper.GetRandomChars(27),
                LastWriting  = DateTime.UtcNow,
                RelativePath = FakeDataTestHelper.GetRandomChars(27),
                Size         = 93184
            };
            buildDefinition.Entries[1] = new BuildDefinitionEntry()
            {
                Attributes   = FileAttributes.Archive,
                Hash         = FakeDataTestHelper.GetRandomChars(27),
                LastWriting  = DateTime.UtcNow,
                RelativePath = FakeDataTestHelper.GetRandomChars(27),
                Size         = 9284
            };

            var serialized = JsonUtility.ToJson(buildDefinition);

            Assert.False(string.IsNullOrWhiteSpace(serialized));

            var deserializedBuildDefinition = new BuildDefinition();
            JsonUtility.Parse(deserializedBuildDefinition, serialized);

            Assert.AreEqual(buildDefinition.Entries.Length, deserializedBuildDefinition.Entries.Length);

            for (var i = 0; i < buildDefinition.Entries.Length; i++)
            {
                var expected = buildDefinition.Entries[i];
                var actual   = deserializedBuildDefinition.Entries[i];

                Assert.AreEqual(expected.Size, actual.Size);
                Assert.AreEqual(expected.Attributes, actual.Attributes);
                Assert.AreEqual(expected.RelativePath, actual.RelativePath);
                Assert.AreEqual(expected.Hash, actual.Hash);
            }
        }


        [Test]
        public void PatchesIndex_Serialize_Test()
        {
            var index = new PatchIndex();
            index.Patches = new List<PatchIndexEntry>(2);
            index.Patches.Add(new PatchIndexEntry()
            {
                From = new Version("0.1.1"),
                To   = new Version("0.1.2")
            });
            index.Patches.Add(new PatchIndexEntry()
            {
                From = new Version("0.1.2"),
                To   = new Version("0.1.3")
            });

            var serialized = JsonUtility.ToJson(index);

            Assert.False(string.IsNullOrWhiteSpace(serialized));

            var deserializedIndex = new PatchIndex();
            JsonUtility.Parse(deserializedIndex, serialized);

            Assert.AreEqual(index.Patches.Count, deserializedIndex.Patches.Count);

            for (var i = 0; i < index.Patches.Count; i++)
            {
                var expected = index.Patches[i];
                var actual   = deserializedIndex.Patches[i];

                Assert.AreEqual(expected.From, actual.From);
                Assert.AreEqual(expected.To, actual.To);
            }
        }

        [Test]
        public void PatchDefinition_Serialize_Test()
        {
            var definition = new PatchDefinition();
            definition.Entries = new List<PatchDefinitionEntry>(2);
            definition.Entries.Add(new PatchDefinitionEntry()
            {
                Attributes   = FileAttributes.Archive,
                LastWriting  = DateTime.UtcNow,
                RelativePath = FakeDataTestHelper.GetRandomChars(27),
                Size         = 93184,
                Operation    = PatchOperation.Updated
            });
            definition.Entries.Add(new PatchDefinitionEntry()
            {
                Attributes   = FileAttributes.Archive,
                LastWriting  = DateTime.UtcNow,
                RelativePath = FakeDataTestHelper.GetRandomChars(27),
                Size         = 9284,
                Operation    = PatchOperation.Updated
            });
            definition.Hash      = FakeDataTestHelper.GetRandomChars(27);
            definition.From      = new Version("0.1.1");
            definition.To        = new Version("0.1.2");
            definition.TotalSize = definition.Entries.Sum(e => e.Size);

            var serialized = JsonUtility.ToJson(definition);

            Assert.False(string.IsNullOrWhiteSpace(serialized));

            var deserializedDefinition = new PatchDefinition();
            JsonUtility.Parse(deserializedDefinition, serialized);

            Assert.AreEqual(definition.Entries.Count, deserializedDefinition.Entries.Count);
            Assert.AreEqual(definition.From, deserializedDefinition.From);
            Assert.AreEqual(definition.To, deserializedDefinition.To);
            Assert.AreEqual(definition.TotalSize, deserializedDefinition.TotalSize);
            Assert.AreEqual(definition.Hash, deserializedDefinition.Hash);

            for (var i = 0; i < definition.Entries.Count; i++)
            {
                var expected = definition.Entries[i];
                var actual   = deserializedDefinition.Entries[i];

                Assert.AreEqual(expected.Size, actual.Size);
                Assert.AreEqual(expected.Attributes, actual.Attributes);
                Assert.AreEqual(expected.RelativePath, actual.RelativePath);
                Assert.AreEqual(expected.Operation, actual.Operation);
            }
        }
    }
}