using MHLab.Patch.Core.Octodiff;
using MHLab.Patch.Tests.Utilities;
using NUnit.Framework;
using System.IO;

namespace MHLab.Patch.Tests
{
    public class DeltaFileApplierTests
    {
        private string _baseFile = "baseFile";
        private string _targetFile = "targetFile";
        private string _deltaFile = "deltaFile";
        private string _outputFile = "outputFile";
        private string _signatureFile = "signatureFile";
        private int _minSize = 1024 * 1024 * 20;
        private int _maxSize = 1024 * 1024 * 30;

        [OneTimeSetUp]
        public void Setup()
        {
            File.WriteAllBytes(_baseFile, FakeDataTestHelper.GetRandomByteArray(_minSize, _maxSize));
            File.WriteAllBytes(_targetFile, FakeDataTestHelper.GetRandomByteArray(_minSize, _maxSize));

            DeltaFileBuilder.Build(_baseFile, _targetFile, _deltaFile, _signatureFile);
        }

        [OneTimeTearDown]
        public void Teardown()
        {
            File.Delete(_baseFile);
            File.Delete(_targetFile);
            File.Delete(_outputFile);
            File.Delete(_deltaFile);
            File.Delete(_signatureFile);
        }

        [TearDown]
        public void ClearOutputFile()
        {
            File.Delete(_outputFile);
        }

        [Test]
        public void Apply_Success()
        {
            DeltaFileApplier.Apply(_baseFile, _deltaFile, _outputFile);

            var targetContent = File.ReadAllBytes(_targetFile);
            var outputContent = File.ReadAllBytes(_outputFile);

            Assert.AreEqual(targetContent.Length, outputContent.Length);

            for (var i = 0; i < targetContent.Length; i++)
            {
                Assert.AreEqual(targetContent[i], outputContent[i]);
            }

            Assert.Pass();
        }
    }
}