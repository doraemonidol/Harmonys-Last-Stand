﻿using System;
using MHLab.Patch.Admin.Localization;
using MHLab.Patch.Admin.Serializing;
using MHLab.Patch.Core.Admin;
using MHLab.Patch.Core.Admin.Progresses;
using MHLab.Patch.Core.IO;
using MHLab.Patch.Core.Logging;
using MHLab.Patch.Core.Versioning;
using MHLab.Patch.Tests.Utilities;
using NUnit.Framework;

namespace MHLab.Patch.Tests
{
    public class CompleteTest
    {
        private IFileSystem       _fileSystem;
        private IAdminSettings    _adminSettings;
        private AdminBuildContext _adminBuildContext;
        
        [OneTimeSetUp]
        public void Setup()
        {
            _fileSystem = new InMemoryFileSystem();
            _adminSettings = new AdminSettings()
            {
                RootPath    = _fileSystem.GetCurrentDirectory().FullPath,
                AppDataPath = _fileSystem.GetApplicationDataPath("PATCH Admin Tool").FullPath
            };
            
            var progress = new Progress<BuilderProgress>();
            
            _adminBuildContext = new AdminBuildContext(_adminSettings, progress)
            {
                Serializer = new JsonSerializer(),
                Logger     = new SimpleLogger(_fileSystem, _adminSettings.GetLogsFilePath(), _adminSettings.DebugMode),
                LocalizedMessages = new EnglishAdminLocalizedMessages(),
                FileSystem = _fileSystem
            };
        }

        [OneTimeTearDown]
        public void Teardown()
        {
        }

        [Test]
        public void CreateBuild()
        {
            FileSystemHelper.CreateNewGameInAppFolder(_fileSystem, _adminSettings);

            _adminBuildContext.BuildVersion = GetNextVersionToBuild();
            
            _adminBuildContext.Initialize();

            var builder = new BuildBuilder(_adminBuildContext);
            builder.Build();
        }

        private IVersion GetNextVersionToBuild()
        {
            var lastVersion = _adminBuildContext.GetLastVersion();

            IVersion newVersion;

            if (lastVersion == null)
            {
                newVersion = _adminBuildContext.VersionFactory.Create();
            }
            else
            {
                newVersion = _adminBuildContext.VersionFactory.Create(lastVersion);
                newVersion.UpdatePatch();
            }

            return newVersion;
        }
    }
}