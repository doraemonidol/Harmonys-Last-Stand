﻿using System;
using System.Collections.Generic;
using MHLab.Patch.Core;
using MHLab.Patch.Core.Client.Advanced.IO.Chunked;
using MHLab.Patch.Core.Client.IO;
using NUnit.Framework;

namespace MHLab.Patch.Tests
{
    public class ChunkStorageTests
    {
        private const int EntriesAmount = 250;

        private ChunkedDownloaderSettings _settings;
        private List<DownloadEntry>       _entries;
        private Random                    _random;

        [SetUp]
        public void Setup()
        {
            _random   = new Random();
            _settings = new ChunkedDownloaderSettings();
            _entries  = new List<DownloadEntry>(EntriesAmount);

            for (var i = 0; i < EntriesAmount; i++)
            {
                var definition = new BuildDefinitionEntry()
                {
                    Size = _random.Next((int) _settings.ChunkSize, (int) _settings.MaxChunkSize) * _random.Next(1, 120)
                };
                var entry = new DownloadEntry("", "", "", "", definition);

                _entries.Add(entry);
            }
        }

        [Test]
        public void All_Chunks_Are_Not_Overlapping_Each_Others()
        {
            var chunks = ChunkStorage.CalculateChunks(_entries, _settings).GetDownloadableChunks();

            foreach (var chunk in chunks)
            {
                foreach (var comparingChunk in chunks)
                {
                    if (chunk == comparingChunk) continue;

                    if (chunk.DownloadEntry != comparingChunk.DownloadEntry) continue;

                    if (chunk.OffsetStart <= comparingChunk.OffsetEnd &&
                        chunk.OffsetStart >= comparingChunk.OffsetStart)
                    {
                        Assert.Fail();
                    }

                    if (chunk.OffsetEnd <= comparingChunk.OffsetEnd &&
                        chunk.OffsetEnd >= comparingChunk.OffsetStart)
                    {
                        Assert.Fail();
                    }
                }
            }
        }
        
        [Test]
        public void All_Chunks_Have_The_Correct_Size()
        {
            var chunks = ChunkStorage.CalculateChunks(_entries, _settings).GetDownloadableChunks();

            foreach (var chunk in chunks)
            {
                Assert.True(chunk.Size > 0);
                Assert.True(chunk.Size <= _settings.MaxChunkSize);
            }
        }
    }
}