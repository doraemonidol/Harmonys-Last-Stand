﻿namespace MHLab.Patch.Core.Client.IO
{
    public class DownloadMetrics : IDownloadMetrics
    {
        public int RunningThreads { get; set; }
    }
}
